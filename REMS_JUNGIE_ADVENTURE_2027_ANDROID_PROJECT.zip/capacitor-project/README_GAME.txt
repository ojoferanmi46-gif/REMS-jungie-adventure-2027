REMS JUNGIE ADVENTURE 2027
Version 0.2 — Expanded Offline Jungle Survival

PLAY
1. Extract this ZIP.
2. Open index.html in Chrome or another modern browser.
3. Tap START ADVENTURE.
4. Use the arrow controls (or WASD / keyboard arrows) to move.
5. Mission 1: collect 5 berries. Walk close and tap ACTION.
6. Mission 2: follow the trail to the campsite marked with a fire icon (🔥).
7. Avoid wild boars. The river is a boundary you cannot cross in this version.

NEW IN VERSION 0.2
- Larger jungle map and minimap
- Winding river and trail
- Campsite, campfire and hut
- Two-stage mission system
- More trees, flowers and vegetation
- Updated HUD and objective marker
- Still playable offline

PROJECT STATUS
This is a playable HTML5 prototype, not an APK yet. Android packaging with
Capacitor and Android Studio is the next step. Version 0.2 uses 2D canvas
graphics; it is not a full 3D game yet.
