REMS JUNGIE ADVENTURE 2027 — ANDROID WRAPPER PROJECT
Based on game version 0.2

IMPORTANT
This ZIP contains the game and a Capacitor project scaffold. It is NOT an APK.
An Android APK must be compiled with the Android SDK/Gradle toolchain.

BUILD ON A COMPUTER WITH ANDROID STUDIO
1. Install Node.js (LTS) and Android Studio.
2. Extract this ZIP.
3. Open a terminal in the 'capacitor-project' folder.
4. Run: npm install
5. Run: npx cap add android
6. Run: npx cap sync android
7. Run: npx cap open android
8. In Android Studio, wait for Gradle sync.
9. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
10. Android Studio will show the generated APK location.

PHONE-ONLY NOTE
Android Studio is not available as a normal Android-phone app. If you only have
your phone, this prepared project can still be transferred to a computer later.
A phone-only cloud build needs a separate build service/account and may have
its own limits. Do not install APKs from unknown sites.

APP ID: com.rems.jungieadventure2027
APP NAME: REMS JUNGIE ADVENTURE 2027
OFFLINE: Game assets are bundled locally in www; no internet connection is
needed to play the game once installed.
